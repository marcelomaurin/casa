			<div class="row space40"></div>   
              
              <!-- Blog Item -->
              <div class="row">
                <div class="span1">
  
                  <div class="blog-icon">
                    <i class="icon-quote-right"></i><br>
                    <h5>Single Post</h5>                  
                  </div>
                     
                </div>
                <div class="span8">
                  <a href="blog-detail.htm"><img src="img/blog/3.jpg" alt=""></a>
  
                  <div class="post-d-info">
                    <a href="blog-detail.htm"><h3>Ancient Timbuktu Texts in Danger?</h3></a>
                    <div class="blue-dark">
                    <i class="icon-user"></i> By Admin <i class="icon-tag"></i> Photography | Portrait <i class="icon-comment-alt"></i> With 12 Comments
                    </div>
                    <p>
                      Donec sed odio dui. Nulla vitae elit libero, a pharetra augue. Nullam id dolor id nibh ultricies vehicula ut id elit. Integer posuere erat a ante venenatis dapibus posuere velit aliquet.Pie wafer wypas candy canes toffee. Cookie icing candy jelly oat cake chupa chups bear claw.
                    </p>
                  </div>
  
                </div>
              </div>
			</div>