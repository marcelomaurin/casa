use jornadadb;

insert users (login, idPessoa, password,status,idRoleGrp,idEmpresa) values ('mmm', 1 , '226468',1,1,1);

