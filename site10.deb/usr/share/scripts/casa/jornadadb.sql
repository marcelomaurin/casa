#Criacao do Banco de Dados
create database jornadadb;





