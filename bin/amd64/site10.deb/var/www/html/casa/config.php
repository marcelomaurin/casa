﻿<?php
    //Inclua aqui as configurações do seu banco de dados
	$dbhost        = '127.0.0.1';
	$database      = 'casadb';
	$dbuser        = 'root';
    $dbpassword    = 'password';
	$urlsrv        = 'your.site';
	$URLLABEL      = 'Casa Inteligente';	
	$emailreply    = 'marcelomaurinmartins@gmail.com';
	$titlesite     = 'Projeto Casa Inteligente';
	$erro_redirect = 'construcao.php';
	$erro_access = 'notaccess.php';
	$homename      = 'Principal';

?>
