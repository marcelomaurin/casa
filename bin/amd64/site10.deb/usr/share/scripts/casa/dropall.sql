
drop database casadb;

