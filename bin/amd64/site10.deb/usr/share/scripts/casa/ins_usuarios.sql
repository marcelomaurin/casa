use casadb;

insert usuarios (usuario, senha) values ('mmm','226468');

