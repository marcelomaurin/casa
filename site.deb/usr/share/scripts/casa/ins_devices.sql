use casadb;

insert devices (devname, devdesc, devtype,devcon,devstatus) values ('sala','controlador sala',1,'192.168.1.210',true);


